#!/usr/bin/perl
use strict;
use warnings;
use Sys::Syslog qw(:standard :macros);
openlog('phone_home daemon', 'nofatal', LOG_DAEMON);

# Instructions for a reverse ssh session are here:
# http://oogies.org/2009/07/08/reverse-ssh-tunneling/
# using tor has a tendency to forget about the host key:
# http://linuxcommando.blogspot.com/2008/10/how-to-disable-ssh-host-key-checking.html
# Don't forget to set up public key authentication:
# http://sial.org/howto/openssh/publickey-auth/#s2
my $username = 'michelle';
my $hidden_server = $username .'@wmnw4fdnbdvzfcrg.onion';
my $ssh_command = '/usr/bin/ssh -R 9000:localhost:22 '.
  '-o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no '.
  $hidden_server;
  
use POSIX qw(setsid sys_wait_h);

chdir '/'                 or die "Can't chdir to /: $!";
umask 0;
open STDIN, '/dev/null'   or die "Can't read /dev/null: $!";
open STDOUT, '>/dev/null' or die "Can't write to /dev/null: $!";
open STDERR, '>/dev/null' or die "Can't write to /dev/null: $!";
defined(my $pid = fork)   or die "Can't fork: $!";
exit if $pid;
setsid                    or die "Can't start a new session: $!";

# Check to make sure the phone home connection is running.
# Instructions for setting up ssh to a tor hidden service are here:
# http://ubuntu-unleashed.com/2008/03/howto-setup-anonymous-ssh-via-tor-hidden-services.html
FORK:
syslog(LOG_INFO, "Phone Home. $ssh_command");
system($ssh_command);
my $exit = $?;
syslog(LOG_ERR, "ssh command exited with $exit. error: $!. $ssh_command");
sleep(5);
goto FORK;
